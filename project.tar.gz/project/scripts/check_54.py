import requests,json,subprocess,psycopg2,operator,os,random
from datetime import datetime
def main():	
        proxy_list=[]
        proxy_file=open('/home/ec2-user/project/info/HTTP_proxy','r')
        for lines in proxy_file:
                lines=lines.split()
                ip=lines[-2]
                port=lines[-1]
                proxy_list.append(':'.join([ip,port]))
        pr_count=random.randint(0,len(proxy_list))
	proxy={'http':'http://%s'%(proxy_list[pr_count%(len(proxy_list))])}
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
	cursor=conn.cursor()
	cursor.execute("select user_req.flying_from, user_req.flying_to,user_req.date_from,user_req.date_to, users.email,users.username from user_req,users where date_from - current_date =54 and user_req.username=users.username")
	records=cursor.fetchall()
	for record in records:
		flying_from=record[0].strip()
		flying_to=record[1].strip()
		date_from=record[2]
		date_to=record[3]
		email=record[4].strip()
		username=record[5]
		if not date_to:
			date_to=''
		print("http://skiplagged.com/api/search.php?from=%s&to=%s&depart=%s&&return=%s&sort=cost"%(flying_from,flying_to,date_from,date_to))
		#return
		try:
			res=requests.get("http://skiplagged.com/api/search.php?from=%s&to=%s&depart=%s&&return=%s&sort=cost"%(flying_from,flying_to,date_from,date_to),proxies=proxy)
		except Exception as e:
			print('failed request')
			records.insert(len(records)-1,record)
			continue
		try:
			python_obj=json.loads(res.text)
		except Exception as e:
			if res.status_code!="403":
				proxy_list.pop(0)
				pr_count+=1
				records.append(record)
				proxy={'http':'http://%s'%(proxy_list[pr_count%(len(proxy_list))])}
				continue
			else:
				print("Counter:%d"%(counter))
				print(str(e))
				print(res.text,res.status_code,res.reason)
				sys.exit(0)
	        FROM=python_obj['info']['from'][1]
	        TO=python_obj['info']['to'][1]
	        email_alert=open("/home/ec2-user/project/temp_files/temp",'w')
	        if python_obj["return"]:
	                
                	final_results={'MIN_TO':[],'MIN_FROM':[]}
        
                	for hashes in python_obj["depart"]:
                	        if len(hashes[0]) < 2:
                	                continue
                	       	else:
                	                
                	                final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][1]])

                	for hashes in python_obj["return"]:
                		final_results['MIN_TO'].append([python_obj["flights"][hashes[3]],hashes[0][0]])

                	depart_dict=[]
                	return_dict=[]

                	for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
                	        depart_dict.append([int(keys[1]),keys[0][0]])

                	for keys in sorted(final_results['MIN_TO'],key=operator.itemgetter(1)):
                	        return_dict.append([int(keys[1]),keys[0][0]])

                	
                	#inner,num=0,0
                	for departs in depart_dict:
                		inner,num=0,0
                        	for returns in return_dict:
                                	num+=1                                
                                        inner+=1
                                        email_alert.write("%d. Price:$%.2f %s <---> %s"%(inner,float(departs[0]+returns[0])/100,python_obj['info']['from'][0],python_obj['info']['to'][0]))
                                        email_alert.write("\t\t\tDEPARTING")
                                        for values in departs[1]:
                                                date1=values[2].find(':',-9)
                                                date1=values[2][:date1]
                                                date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


                                                date2=values[4].find(':',-9)
                                                date2=values[4][:date2]
                                                date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()



                                                email_alert.write("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
                                        email_alert.write("\t\t\tRETURNING")
                                        for values in returns[1]:
                                                date1=values[2].find(':',-9)
                                                date1=values[2][:date1]
                                                date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


                                                date2=values[4].find(':',-9)
                                                date2=values[4][:date2]
                                                date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()

                                                email_alert.write("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))

                                        email_alert.write("\n")

              				if num>=10:
						break
        	else:   
                	#price=int(python_obj["depart"][0][0][0])
                        final_results={'MIN_TO':[],'MIN_FROM':[]}
        		for hashes in python_obj["depart"]:
                        	if len(hashes[0]) < 1:
                       	 	        continue
                        	else:
                        		final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][0]])
                	depart_dict=[]

                	for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
                	        depart_dict.append([int(keys[1]),keys[0][0]])
 
                
 	               	#inner,num=0,0
        	       	for departs in depart_dict:
 	               		inner,num=0,0
				num+=1
                       		inner+=1
                        	email_alert.write("%d. Price:$%.2f %s ---> %s"%(inner,float(departs[0])/100,python_obj['info']['from'][0],python_obj['info']['to'][0]))
                        	email_alert.write("\t\t\tDEPARTING\n")
                        	for values in departs[1]:
                        		date1=values[2].find(':',-9)
                        	        date1=values[2][:date1]
                        	        date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
	
                        	        date2=values[4].find(':',-9)
                        	        date2=values[4][:date2]
                        	        date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
	
                        	        email_alert.write("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
                        	        email_alert.write("\n")
				email_alert.write("\n")
				if num >= 10:
					break
        	email_alert.close()
		print("Sending email to %s"%(email))	
		cat=subprocess.Popen(("cat","/home/ec2-user/project/temp_files/temp"),stdout=subprocess.PIPE)
		outfile=subprocess.check_output(("mailx","-s",''.join(['Reminder: 54 days ',flying_from,'-->',flying_to]),email),stdin=cat.stdout)
		os.remove('/home/ec2-user/project/temp_files/temp')
		

main()
