import json,requests,heapq,operator,psycopg2,sys,random
from datetime import datetime
from time import sleep


def explore(target_price,price_max,flying_from,date_from,date_to,output):
	#sections=["America","Africa","Asia","Atlantic","Australia","Europe","Indian","Pacific"]
	sections=["America","Europe"]
	#proxy_list=["68.87.73.163:80","68.87.73.164:80","69.74.29.206:80","47.88.14.37:8081"]
	curr_time=datetime.now().ctime()
	proxy_list=[]
	proxy_file=open('/home/ec2-user/project/info/HTTP_proxy','r')
        for lines in proxy_file:
                lines=lines.split()
                ip=lines[-2]
                port=lines[-1]
                proxy_list.append(':'.join([ip,port]))
	#print(proxy_list)
	prx_count=random.randint(0,len(proxy_list))
	regions={}
	for section in sections:
		regions[section]=[]
	counter=0
	proxy={'http':'http://%s'%(proxy_list[prx_count%(len(proxy_list))])}
	trial=open(output,'w')
	trial.write("<html><br><br><body>")
	price_point=float(price_max)*100
        target_point=float(target_price)*100
	for region in sorted(regions.keys()):
		if date_to:
                	trial.write("<h1 align='center'>%s <--> %s</h1>(%s)<br>"%(','.join(flying_from),region,curr_time))
        	else:
                	trial.write("<h1 align='center'>%s --> %s</h1>(%s)<br>"%(','.join(flying_from),region,curr_time))
		trial.write("<input align='center' style='background-color:aquamarine;color:black;font:20px;height:40px; width:70px; align:center; border-radius:25px; border:5px solid black;' type='button' onclick='show(this)' name='%s' value='Hide'><br>"%(region))
		trial.write("<div id='%s'>"%(region))
		print("Region ---> %s"%(region))
		conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
		cursor=conn.cursor()
		#print("select iata_faa from countries where continent='%s'"%(region))
		cursor.execute("select iata_faa from countries where continent='%s' order by iata_faa"%(region))
		#cursor.execute("select iata_faa from countries where continent='%s' and iata_faa='ABY' order by iata_faa"%(region))
		records=cursor.fetchall()
		final_list=[]
		email_list=[]			       
		#email_alert=open('alert_file','w')
		airlines={}
		num,inner=0,0
		for record in records:
			flying_to=record[0].strip()
			if not flying_to:
				continue
			#print("flying to %s"%(flying_to))
			for origin in flying_from:
				counter+=1
				try:
		        		res=requests.get("http://skiplagged.com/api/search.php?from=%s&to=%s&depart=%s&&return=%s&sort=cost"%(origin,flying_to,date_from,date_to),proxies=proxy)
				except requests.exceptions.ConnectionError:
					#print(str(e))
					flying_from.append(origin)
                        		backip=proxy_list.pop(0)
					proxy_list.append(backip)
					print("Proxy List Length %d"%(len(proxy_list)))
                        		#pr_count+=1
					sleep(30)
                        		continue
				try:
		        		python_obj=json.loads(res.text)
				except Exception as e:
					print(res.status_code)
					if res.status_code!="403":
						back_ip=proxy_list.pop(0)
						proxy_list.append(back_ip)
						#proxy_list.pop(index(prx_count%(len(proxy_list))))
						#prx_count+=1
						records.append(record)
						print("Proxy List Length %d"%(len(proxy_list)))
						print("Switching From %s to %s"%(proxy,proxy_list[prx_count%(len(proxy_list))]))
						proxy={'http':'http://%s'%(proxy_list[prx_count%(len(proxy_list))])}
						continue
					else:
						print("Counter:%d"%(counter))
						print(str(e))
						print(res.text,res.status_code,res.reason)
						sys.exit(0)
				if not python_obj['depart']:
					continue
		        	#print("http://skiplagged.com/api/search.php?from=%s&to=%s&depart=%s&&return=%s&sort=cost"%(origin,flying_to,date_from,date_to))
				print("%s-->%s"%(origin,flying_to))
		        	FROM=python_obj['info']['from'][1]
		        	TO=python_obj['info']['to'][1]
				for keys in python_obj['airlines'].keys():
					if airlines.has_key(keys):
						continue
					else:
						airlines[keys]=python_obj['airlines'][keys]
		        	if python_obj["return"]:
		                	price=max(int(python_obj["depart"][0][0][0]),int(python_obj["return"][0][0][0]))
		                	if price>price_point:
		                        	#print("No flights found, cheapest flight=%.2f...exiting"%(float(price)/100))
		                        	#trial.write("<h3>No flights found, cheapest flight=%.2f"%(float(price)/100))
						continue
		                	final_results={'MIN_TO':[],'MIN_FROM':[]}
		                	for hashes in python_obj["depart"]:
		                	        if len(hashes[0]) < 2:
		                        	        continue
						#print(hashes[0][1],price)
		                        	if int(hashes[0][1])<=price:
		                        	        final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][1]])
		                	for hashes in python_obj["return"]:
		                        	if int(hashes[0][0])<=price:
		                        	        final_results['MIN_TO'].append([python_obj["flights"][hashes[3]],hashes[0][0]])
		                	depart_dict=[]
		                	return_dict=[]
		                	for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
		                	        depart_dict.append([int(keys[1]),keys[0][0]])
					
		                	for keys in sorted(final_results['MIN_TO'],key=operator.itemgetter(1)):
		                	        return_dict.append([int(keys[1]),keys[0][0]])
		                	if (depart_dict[0][0]+return_dict[0][0])<=price_point:
		                		flight_sum=(depart_dict[0][0]+return_dict[0][0])
		                	        final_list.append((flight_sum,depart_dict[0][1],return_dict[0][1]))
		                	#if depart_dict[0][0]+return_dict[0][0]<=target_point:
		                		#flight_sum=depart_dict[0][0]+return_dict[0][0]
		                	        #email_list.append((flight_sum,depart_dict[0][1],return_dict[0][1]))
		        	else:
		                	price=int(python_obj["depart"][0][0][0])
		                	if price>price_point:
		                	        #print("No flights found,cheapest flight %.2f...exiting"%(float(price)/100))
		                	        #trial.write("<h3>No flights found, cheapest flight=%.2f"%(float(price)/100))
						continue
		                	final_results={'MIN_TO':[],'MIN_FROM':[]}
					#print(price)
		                	for hashes in python_obj["depart"]:
		                        	if len(hashes[0]) < 1:
		                                	continue
		                        	if int(hashes[0][0])<=price_point:
		                                	 final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][0]])
		                	depart_dict=[]
		                	for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
		                        	depart_dict.append([int(keys[1]),keys[0][0]])
		               
		                	if depart_dict[0][0]<=price_point:
		                		final_list.append((depart_dict[0][0],depart_dict[0][1]))
		                	#if depart_dict[0][0]<=target_point: 
		                		#email_list.append((depart_dict[0][0],depart_dict[0][1]))
		#print(final_list)
		if date_to:
		        while final_list:
				if len(regions[region])>=25:
					break
				heapq.heapify(final_list)
				num+=1
		                flight=heapq.heappop(final_list)
				regions[region].append(final_list)
		               	heapq.heapify(final_list)
				dest=flight[1][-1][3]
				cursor.execute("select city, country from countries where iata_faa='%s'"%(dest))
				records=cursor.fetchone()
				city=records[0]
				country=records[1]
				trial.write("\t\t\t<h1>%s(%s,%s)</h1>"%(dest,city,country))
				trial.write("<h2>%d. TOTAL:$%.2f</h2>"%(num,float(flight[0])/100))
				trial.write("\t\t\t<h3>DEPARTING</h3>")
		                print("%d. TOTAL:$ %.2f"%(num,float(flight[0])/100))
		                print("\t\tDeparting")
		                for values in flight[1]:
		                        date1=values[2].find(':',-9)
		                       	date1=values[2][:date1]
		                       	date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
		                       	date2=values[4].find(':',-9)
		                       	date2=values[4][:date2]
		                       	date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
		                       	print("%s(%s) %s %s ---> %s %s"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
					trial.write("%s(%s) %s %s ---> %s %s<br>"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
		                print("\n")
				trial.write("\t\t\t<br><h3>RETURNING</h3>")
		                print("\t\tReturning")
		                for values in flight[2]:
		                       	date1=values[2].find(':',-9)
		                       	date1=values[2][:date1]
		                       	date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
		                       	date2=values[4].find(':',-9)
		                       	date2=values[4][:date2]
		                       	date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
		                       	print("%s(%s) %s %s ---> %s %s"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
					trial.write("%s(%s) %s %s ---> %s %s<br>"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
		                print("\n")
				trial.write("<br>")
			
			#while email_list:
				#heapq.heapify(email_list)
				#inner+=1
				#flight=heapq.heappop(email_list)
				#email_alert.write("%d. TOTAL:$ %.2f\n"%(inner,float(flight[0])/100))
				#email_alert.write("\t\tDeparting\n")
				#for values in flight[1]:
                               	#	date1=values[2].find(':',-9)
                               	#	date1=values[2][:date1]
                               	#	date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
                               	#	date2=values[4].find(':',-9)
                               	#	date2=values[4][:date2]
                               	#	date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
				#	email_alert.write("%s(%s) %s %s ---> %s %s\n"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
				#email_alert.write('\n')
				#email_alert.write("\t\tReturning\n")
				#for values in flight[2]:
                               	#	date1=values[2].find(':',-9)
                               	#	date1=values[2][:date1]
                               	#	date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
                               	#	date2=values[4].find(':',-9)
                               	#	date2=values[4][:date2]
                               	#	date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
				#	email_alert.write("%s(%s) %s %s ---> %s %s\n"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))		
				#email_alert.write('\n')
		else:
		       	while final_list:
				if len(regions[region])>=25:
					break
				heapq.heapify(final_list)
				num+=1
		               	flight=heapq.heappop(final_list)
				regions[region].append(flight)
				dest=flight[1][-1][3]
                                cursor.execute("select city, country from countries where iata_faa='%s'"%(dest))
                                records=cursor.fetchone()
				print(records)
                                city=records[0]
                                country=records[1]
                                trial.write("\t\t\t<h1>%s(%s,%s)</h1>"%(dest,city,country))
				trial.write("<h2>%d. TOTAL:$%.2f</h2>"%(num,float(flight[0])/100))
				trial.write("\t\t\t<h3>DEPARTING</h3>")
		               	print("TOTAL:$%.2f"%(float(flight[0])/100))
		               	print("\t\tDeparting")
		               	for values in flight[1]:
		               	        date1=values[2].find(':',-9)
		               	        date1=values[2][:date1]
		               	        date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
		               	        date2=values[4].find(':',-9)
		               	        date2=values[4][:date2]
		               	        date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
		               	        print("%s(%s) %s %s ---> %s %s"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
					trial.write("%s(%s) %s %s ---> %s %s<br>"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
		               	print("\n")
				trial.write("<br>")
			#while email_list:
                       	#	heapq.heapify(email_list)
                        #	inner+=1
                        #	flight=heapq.heappop(email_list)
                        #	email_alert.write("%d. TOTAL:$ %.2f\n"%(inner,float(flight[0])/100))      
                        #	email_alert.write("\t\tDeparting\n")
                        #	for values in flight[1]:
                        #        	date1=values[2].find(':',-9)
                        #        	date1=values[2][:date1]
                        #        	date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
                        #        	date2=values[4].find(':',-9)
                        #        	date2=values[4][:date2]
                        #        	date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
                        #        	email_alert.write("%s(%s) %s %s ---> %s %s\n"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
                        #	email_alert.write('\n')
		trial.write('</div>') 
	trial.close()
	#email_alert.close()
	#print(regions)
#explore('300','600',['ATL'],'2016-08-05','2016-08-08','something')
