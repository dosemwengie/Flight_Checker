import psycopg2,os

def main():
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
        cursor=conn.cursor()
        cursor.execute("select rowid from user_req where date_from < current_date")
	row_records=cursor.fetchall()
	for row_record in row_records:
		rowid=str(row_record[0]).strip()
		cursor.execute("select username, target_price, price_max, flying_from, flying_to ,date_from, date_to from user_req where rowid='%s'"%(rowid))
        	record=cursor.fetchone()
        	record=list(record)
        	for idx,data in enumerate(record):
                	record[idx]=str(data).strip()
                	if record[idx]=="None":
                        	record[idx]=''
		if len(record[3].split(','))>1:
			record[3]='-'.join(record[3].split(','))
		output='_'.join(record)
		cursor.execute("select filename from %s_data where rowid='%s'"%(record[0],rowid))
		output=cursor.fetchone()[0]
        	print("output to delete %s"%(output))
        	cursor.execute("delete from %s_data where rowid='%s'"%(record[0],rowid))
        	conn.commit()
        	cursor.execute("delete from user_req where rowid='%s'"%(rowid))
        	conn.commit()
        	if os.path.isfile(output):
			os.remove(output)
main()
