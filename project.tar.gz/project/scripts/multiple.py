import json,requests,heapq,operator
import random
from datetime import datetime



def do_work_multiple(target_price,price_max,flying_from,flying_to,date_from,date_to,output):
	final_list=[]
	email_list=[]			       
	email_alert=open('alert_file','w')
	airlines={}
	trial=open(output,'w')
	trial.write("<br><br>")
	proxy_list=[]
	proxy_file=open('/home/ec2-user/project/info/HTTP_proxy','r')
	for lines in proxy_file:
		lines=lines.split()
		ip=lines[-2]
		port=lines[-1]
		proxy_list.append(':'.join([ip,port]))
	pr_count=random.randint(0,len(proxy_list))
	proxy={'http':'http://%s'%(proxy_list[pr_count%len(proxy_list)])}
	curr_time=datetime.now().ctime()
	trial.write("<div align='center'><h2><span class='col-md-12 label label-default'>%s</span></h2></div>\n"%(curr_time))
	trial.write("<div align='center'><div class='col-md-12  btn btn-primary btn-lg' data-toggle='collapse' data-target='#%s'>\n<h1>"%(output.replace('/','-')))
	if date_to:
		trial.write("%s <span class='glyphicon glyphicon-refresh'></span>%s\n"%(','.join(flying_from),flying_to))
	else:
		trial.write("%s <span class='glyphicon glyphicon-right-arrow'></span>%s\n"%(','.join(flying_from),flying_to))
	trial.write("</h1>\n</div>\n</div>\n<div class='col-md-6 col-md-offset-3'>\n")
	trial.write("<div id='%s' class='collapse'>\n"%(output.replace('/','-')))
	trial.write("<table class='table table-condensed table-bordered' align='center' style='background-color:azure;'>\n")
	num,inner=0,0
	for origin in flying_from:
		if not origin:
			continue
		proxy={'http':'http://%s'%(proxy_list[pr_count%len(proxy_list)])}
	        price_point=float(price_max)*100
	        target_point=float(target_price)*100
		try:
	        	res=requests.get("http://skiplagged.com/api/search.php?from=%s&to=%s&depart=%s&&return=%s&sort=cost"%(origin,flying_to,date_from,date_to),proxies=proxy)
	        	python_obj=json.loads(res.text)
			if res.status_code!=200:
				flying_from.append(origin)
				print(res.status_code,proxy)
				proxy_list.pop(0)
				continue
		except:
			flying_from.append(origin)
                        proxy_list.pop(0)
                        continue
			
		print("%s-->%s=%s"%(origin,flying_to,python_obj['depart'][0][0]))
	        
	        FROM=python_obj['info']['from'][1]
	        TO=python_obj['info']['to'][1]
		for keys in python_obj['airlines'].keys():
			if airlines.has_key(keys):
				continue
			else:
				airlines[keys]=python_obj['airlines'][keys]
	        if python_obj["return"]:
	                price=max(int(python_obj["depart"][0][0][0]),int(python_obj["return"][0][0][0]))
	                if price>price_point:
	                        print("No flights found, cheapest flight=%.2f...exiting"%(float(price)/100))
	                        trial.write("<tr><td><h3><div class='panel panel-danger'><div class='panel-heading' style='text-align:center;'>No flights found, cheapest flight = $%.2f</div></div></h3></td></tr>"%(float(price)/100))
				continue
	                final_results={'MIN_TO':[],'MIN_FROM':[]}
	                for hashes in python_obj["depart"]:
				print(hashes[0])
	                        if len(hashes[0]) < 2:
	                                continue
	                        if int(hashes[0][1])<=price:
	                                final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][1]])
	                for hashes in python_obj["return"]:
	                        if int(hashes[0][0])<=price:
	                                final_results['MIN_TO'].append([python_obj["flights"][hashes[3]],hashes[0][0]])
	                depart_dict=[]
	                return_dict=[]
	                for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
	                        depart_dict.append([int(keys[1]),keys[0][0]])
	                for keys in sorted(final_results['MIN_TO'],key=operator.itemgetter(1)):
	                        return_dict.append([int(keys[1]),keys[0][0]])
	                for departs in depart_dict:
	                        for returns in return_dict:
					print(departs[0],returns[0])
	                                if (departs[0]+returns[0])<=price_point:
	                                        flight_sum=(departs[0]+returns[0])
	                                        final_list.append((flight_sum,departs[1],returns[1]))
	                                if (departs[0]+returns[0])<=target_point:
	                                        flight_sum=(departs[0]+returns[0])
	                                        email_list.append((flight_sum,departs[1],returns[1]))
	        else:
	                
	                price=int(python_obj["depart"][0][0][0])
	                if price>price_point:
	                        print("No flights found,cheapest flight %.2f...exiting"%(float(price)/100))
				trial.write("<tr><td><h3><div class='panel panel-danger'><div class='panel-heading' style='text-align:center;'>No flights found, cheapest flight = $%.2f</div></div></h3></td></tr>"%(float(price)/100))
	                        #trial.write("<h2><span class='label label-default col-md-12'>No flights found, cheapest flight=%.2f</span></h2>\n"%(float(price)/100))
				continue
	                final_results={'MIN_TO':[],'MIN_FROM':[]}
	                for hashes in python_obj["depart"]:
	                        if len(hashes[0]) < 1:
	                                continue
	                        if int(hashes[0][0])<=price_point:
	                                 final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][0]])
	                depart_dict=[]
	                for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
	                        depart_dict.append([int(keys[1]),keys[0][0]])
	               
	                for departs in depart_dict:
	                        if departs[0]<=price_point:
	                                final_list.append((departs[0],departs[1]))
	                              
	                        if departs[0]<=target_point: 
	                                email_list.append((departs[0],departs[1]))

	if python_obj['return']:
	        while final_list:
			heapq.heapify(final_list)
			num+=1
	                flight=heapq.heappop(final_list)
			trial.write("<tr><td><h2><span class='label label-default col-md-12'>%d. TOTAL:$%.2f</span></h2></td></tr>\n"%(num,float(flight[0])/100))
			trial.write("<tr><td><h3><div class='panel panel-info'><div class='panel-heading' style='text-align:center;'>DEPARTING</div></div></h3></td></tr>")
	                print("%d. TOTAL:$ %.2f"%(num,float(flight[0])/100))
	                print("\t\tDeparting")
	                for values in flight[1]:
	                        date1=values[2].find(':',-9)
	                        date1=values[2][:date1]
	                        date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
	                        date2=values[4].find(':',-9)
	                        date2=values[4][:date2]
	                        date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
	                        print("%s(%s) %s %s ---> %s %s"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
				trial.write("<tr><td><h4> <span class='label label-info'><span class='glyphicon glyphicon-plane'></span>&nbsp%s(%s)</span>&nbsp\n"%(values[0],airlines[values[0][:2]]))
				trial.write("<span class='label label-info'>%s %s&nbsp<span class='glyphicon glyphicon-circle-arrow-right'></span> &nbsp %s %s\n"%(values[1],date1,values[3],date2))
				trial.write("</span></h4></td></tr>\n")
	                print("\n")
			trial.write("<tr><td><h3><div class='panel panel-danger'><div class='panel-heading' style='text-align:center;'>RETURNING</div></div></h3></td></tr>")
	                print("\t\tReturning")
	                for values in flight[2]:
	                        date1=values[2].find(':',-9)
	                        date1=values[2][:date1]
	                        date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
	                        date2=values[4].find(':',-9)
	                        date2=values[4][:date2]
	                        date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
	                        print("%s(%s) %s %s ---> %s %s"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
				trial.write("<tr><td><h4> <span class='label label-danger'><span class='glyphicon glyphicon-plane'></span>&nbsp%s(%s)</span>&nbsp\n"%(values[0],airlines[values[0][:2]]))
                                trial.write("<span class='label label-danger'>%s %s&nbsp<span class='glyphicon glyphicon-circle-arrow-right'></span> &nbsp %s %s\n"%(values[1],date1,values[3],date2))
                                trial.write("</span></h4></td></tr>\n")
	                print("\n")
		
		while email_list:
			heapq.heapify(email_list)
			inner+=1
			flight=heapq.heappop(email_list)
			email_alert.write("%d. TOTAL:$ %.2f\n"%(inner,float(flight[0])/100))
			email_alert.write("\t\tDeparting\n")
			for values in flight[1]:
                                date1=values[2].find(':',-9)
                                date1=values[2][:date1]
                                date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
                                date2=values[4].find(':',-9)
                                date2=values[4][:date2]
                                date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
				email_alert.write("%s(%s) %s %s ---> %s %s\n"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
			email_alert.write('\n')
			email_alert.write("\t\tReturning\n")
			for values in flight[2]:
                                date1=values[2].find(':',-9)
                                date1=values[2][:date1]
                                date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
                                date2=values[4].find(':',-9)
                                date2=values[4][:date2]
                                date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
				email_alert.write("%s(%s) %s %s ---> %s %s\n"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))		
			email_alert.write('\n')
	else:
	        while final_list:
			heapq.heapify(final_list)
			num+=1
	                flight=heapq.heappop(final_list)
			trial.write("<tr><td><h2><span class='label label-default col-md-12'>%d. TOTAL:$%.2f</span></h2></td></tr>\n"%(num,float(flight[0])/100))
			trial.write("<tr><td><h3><div class='panel panel-primary'><div class='panel-heading' style='text-align:center;'>DEPARTING</div></div></h3></td></tr>")	
	                print("TOTAL:$%.2f"%(float(flight[0])/100))
	                print("\t\tDeparting")
	                for values in flight[1]:
	                        date1=values[2].find(':',-9)
	                        date1=values[2][:date1]
	                        date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
	                        date2=values[4].find(':',-9)
	                        date2=values[4][:date2]
	                        date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
	                        print("%s(%s) %s %s ---> %s %s"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
				trial.write("<tr><td><h4> <span class='label label-info'><span class='glyphicon glyphicon-plane'></span>%s(%s)</span>&nbsp\n"%(values[0],airlines[values[0][:2]]))
                                trial.write("<span class='label label-info'>%s %s<span class='glyphicon glyphicon-circle-arrow-right'></span> &nbsp %s %s\n"%(values[1],date1,values[3],date2))
                                trial.write("</span></h4></td></tr>\n")	
	                heapq.heapify(final_list)
	                print("\n")
		while email_list:
                        heapq.heapify(email_list)
                        inner+=1
                        flight=heapq.heappop(email_list)
                        email_alert.write("%d. TOTAL:$ %.2f\n"%(inner,float(flight[0])/100))      
                        email_alert.write("\t\tDeparting\n")
                        for values in flight[1]:
                                date1=values[2].find(':',-9)
                                date1=values[2][:date1]
                                date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()
                                date2=values[4].find(':',-9)
                                date2=values[4][:date2]
                                date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()
                                email_alert.write("%s(%s) %s %s ---> %s %s\n"%(values[0],airlines[values[0][:2]],values[1],date1,values[3],date2))
                        email_alert.write('\n')
	trial.write('</table></div></div>') 
	trial.close()
	email_alert.close()
