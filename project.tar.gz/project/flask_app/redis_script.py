import redis

r=redis.Redis()
r.sadd('followers','somebody')

