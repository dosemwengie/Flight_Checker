from flask import Flask,render_template,request,session
import os
import psycopg2
import json
import re
from datetime import datetime

app = Flask(__name__)
app.config.from_pyfile('config.py')

conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker");
cursor=conn.cursor()

@app.route('/', methods=['POST','GET','OPTIONS'])
def init():
	print(request.values)
	if request.method == "GET":
		print("GETTYY")
		return render_template("main.html")
	else:
		conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
		cursor=conn.cursor()
		print("POSTTTY")
		print(request.values.keys())
		if 'username' in request.values.keys():
			user=request.values['username']
			user=user.lower().strip()
			print("Select username from users where username=%s"%(user))
			cursor.execute("Select username from users where username='%s'"%(user))
			records=cursor.fetchall()
			if records:
				print(records)
				return render_template("welcome.html",user=user,files=records)
			else:
				print False
			conn.close()		
			return render_template("main.html")
		else:
			return ""

@app.route('/checkLogin', methods=['GET','POST','OPTIONS'])
def check():
	if 'new_user' in request.values.keys():
		conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
                cursor=conn.cursor()
                new_user=request.values['new_user']
		new_user=new_user.lower().strip()
		email=request.values['email']
                cursor.execute("Select username from users where username='%s'"%(new_user))
                records=cursor.fetchone()
                if records:
                	print(records)
                        print("USER %s EXISTS"%(records[0].rstrip()))
                        script="ERROR:User %s already exists,Try Again"%(records[0].rstrip())
                        print(script)
                        returner={'color':'pink','info':script,'reveal':''}
                        returner=json.dumps(returner)
                        return(returner)
                        #return render_template("register.html",script=script)
		else:
			cursor.execute("Insert into users values('%s','%s')"%(new_user,email))
			cursor.execute("create table %s_data (filename varchar )"%(new_user))
			conn.commit()
			user_path=os.path.join('/user_data/',new_user)
			os.mkdir(user_path)
                        returner={'color':'white','info':'User %s created'%(new_user),'reveal':'true','secret_url':'/success_login'}
                        returner=json.dumps(returner)
                        return returner

@app.route('/register', methods=['POST','GET','OPTIONS'])
def route():
	return render_template("register.html")

@app.route('/success_login', methods=['POST','GET','OPTIONS'])
def homepage():
	print(request.values)
	user=request.values['username']
	user=user.lower().strip()
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
        cursor=conn.cursor()
	#cursor.execute("Select * from %s_data order by price,cur_date,time"%(user))
	cursor.execute("Select target_price,price_max,flying_from,flying_to,date_from,date_to,rowid from user_req where username='%s'"%(user))
	data=[]
	records=cursor.fetchall()
	if records:
		cursor.execute("select filename from %s_data"%(user))
		flight_data=cursor.fetchall()
		flights=''
		if flight_data:
			for flight in flight_data:
				print(flight[0])
				flight=flight[0]
				f=open(flight,'r')
				flights=''.join([flights,f.read()])
				f.close()
		data.append(("Target Price","Max Price","Flying From","Flying To","From Date","To Date","Delete"))
		for record in records:
			rowid=record[-1]
			from_date=record[4].ctime().split()
			final_from_date=from_date[1]+" "+from_date[2]+","+from_date[4]
			if record[5]:
                                to_date=record[5].ctime().split()
                                final_to_date=to_date[1]+" "+to_date[2]+","+to_date[4]
                        else:
                                final_to_date=''
			data.append((str(record[0]),str(record[1]),record[2],record[3]\
			,final_from_date,final_to_date,'<input class="check" value=%s type="checkbox">'%(rowid)))
		user=''.join([user[0].upper(),user[1:]])
		return render_template("user_page.html",user=user,rows=data,flights=flights)
	else:
		cursor.execute("Select username from users where username='%s'"%(user))
		records=cursor.fetchall()
		if records:
			user=''.join([user[0].upper(),user[1:]])
			return render_template("user_enter.html",user=user)
		else:
			return render_template("register.html")
@app.route('/insert_data', methods=['POST','GET','OPTIONS'])
def update_page():
        print("Update Page",request.values)
	username=request.values['username']
	username=username.lower().strip()
	target_price=request.values['target_price']
	price_max=request.values['price_max']
	source=re.split(',|\ +',request.values['source'])
	if len(source)>1:
		source=','.join(source)
		#return
	destination=request.values['destination']
	leaving=request.values['leaving']
	returning=request.values['returning']
        conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
        cursor=conn.cursor()
	print('insert into user_req values("%s","%s","%s","%s","%s","%s","%s","Y")'%(username,target_price,price_max,source,destination,leaving,returning))
	if not returning:
        	cursor.execute("insert into user_req values('%s','%s','%s','%s','%s','%s',NULL,'Y')"%(username,target_price,price_max,source,destination,leaving))
	else:
		if datetime.strptime(leaving,'%Y-%m-%d') <= datetime.strptime(returning,'%Y-%m-%d'):
        		cursor.execute("insert into user_req values('%s','%s','%s','%s','%s','%s','%s','Y')"%(username,target_price,price_max,source,destination,leaving,returning))
		else:	
			username=''.join([username[0].upper(),username[1:]])
			return render_template("user_page.html",user=username,error="ERROR:Return Date Must be After Departure")
	conn.commit()
        data=[]
	#cursor.execute("Select * from %s_data order by price,cur_date,time"%(username))
        #records=cursor.fetchall()
	cursor.execute("Select target_price,price_max,flying_from,flying_to,date_from,date_to,rowid from user_req where username='%s'"%(username))
	records=cursor.fetchall()
	if records:
                cursor.execute("select filename from %s_data"%(username))
                flight_data=cursor.fetchall()
                flights=''
                if flight_data:
                        for flight in flight_data:
                                print(flight[0])
                                flight=flight[0]
                                f=open(flight,'r')
                                flights=''.join([flights,f.read()])
                                f.close()

		data.append(("Target Price","Max Price","Flying From","Flying To","From Date","To Date","Delete"))
		for record in records:
			print(record)
			rowid=record[-1]
			from_date=record[4].ctime().split()
			final_from_date=from_date[1]+" "+from_date[2]+","+from_date[4]
			if record[4]:
				to_date=record[4].ctime().split()
				final_to_date=to_date[1]+" "+to_date[2]+","+to_date[4]
			else:
				final_to_date=''
			data.append((str(record[0]),str(record[1]),record[2],record[3]\
			,final_from_date,final_to_date,'<input class="check" value=%s type="checkbox">'%(rowid)))
		username=''.join([username[0].upper(),username[1:]])
		print("Exiting Update")
                return render_template("user_page.html",user=username,rows=data,flights=flights)

@app.route('/changeUp', methods=['POST','GET','OPTIONS'])
def changer():
	print("Change UP",request.values)
	rowid=request.values['rowid']
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
        cursor=conn.cursor()
	cursor.execute("select username, target_price, price_max, flying_from, flying_to ,date_from, date_to from user_req where rowid='%s'"%(rowid))
	record=cursor.fetchone()
	record=list(record)
	for idx,data in enumerate(record):
		record[idx]=str(data).strip()
		if record[idx]=="None":
			record[idx]=''
	output='_'.join(record)
	output=os.path.join('/user_data',output)
	cursor.execute("delete from %s_data where filename='%s'"%(record[0],output))
	conn.commit()
	cursor.execute("delete from user_req where rowid='%s'"%(rowid))
	conn.commit()
	if os.path.isfile(output):
		os.remove(output)
	return 'True'

@app.route('/getAirport', methods=['POST','GET','OPTIONS'])
def finder():
	print("Get Airport",request.values)
	city=request.values['city'].strip()
	city=''.join([city[0].upper(),city[1:]])
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
        cursor=conn.cursor()
	data=[]
	print("Select name,city,country,iata_faa from iata where city='%s'"%(city))
	cursor.execute("Select name,city,country,iata_faa from iata where city='%s'"%(city))
	records=cursor.fetchall()
	if not records:
		error="Could not find city %s"%(city)
		return render_template("airport_finder.html",error=error)
	else:
		data.append(['Airport Name','City','Country','IATA'])
		for record in records:
			data.append(record)
		return render_template("airport_finder.html",data=data)

@app.route('/validate_airport',methods=['POST','GET','OPTIONS'])
def validify():
	print("Validify",request.values)
	sources=re.split(',|\ +',request.values['source'].upper())
	if len(sources)>1:
		print(sources)
		#return
	destination=request.values['destination'].upper()
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
        cursor=conn.cursor()
	for source in sources:
		cursor.execute("select iata_faa from iata where iata_faa='%s' "%(source))
		record=cursor.fetchone()
		if not record:
			returner=json.dumps({'stat':'Invalid','reveal':"source "+source})
			print(returner)
			return returner
	cursor.execute("select iata_faa from iata where iata_faa='%s' "%(destination))
	record=cursor.fetchone()
	if not record:
		return json.dumps({'stat':'Invalid','reveal':"destination "+destination})
	return json.dumps({'stat':'Valid','reveal':''})
	


if __name__ == '__main__':
	app.run(host='0.0.0.0',debug=True)
