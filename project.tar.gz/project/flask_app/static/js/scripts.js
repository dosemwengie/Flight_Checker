$(document).ready(function(){
$(".check").change(function(){
if(this.checked){
console.log("here");
word=$(this).val();
$.ajax({
url: "/changeUp",
data:{"rowid":word},

success:function(response){
},
error:function(st){
alert(st);
}
});
$(this).parent().parent().remove();
}
});


     var address="http://"+document.domain +':' + location.port + '/test';
        console.log(address);
        var socket = io.connect(address);
        socket.on('my response', function(msg){
		console.log(msg);
                $('#log').html('<p data-spy="scroll">'+msg.data+'</p>');
                $('#chatter').html('<p data-spy="scroll">'+msg.followers+'</p>');
                });        
        $('form#broadcast').submit(function(event){
                        console.log("2s");
                socket.emit('my broadcast event', {data: $('#broadcast_data').val(), user:"{{user}}"});
                $('#broadcast_data').val('');
                return false;
        });
        $("form#broadcast input").bind('keypress',function(e){
                if(e.keyCode==13){
                socket.emit('my broadcast event', {data: $('#broadcast_data').val(),user:"{{user}}"});
                $('#broadcast_data').val('');
                return false;
                }
        });

});


function show(stringer){
console.log(stringer.name);
var something=stringer.name
console.log(document.getElementById(something).style.display);

if(document.getElementById(something).style.display==''){
document.getElementById(something).style.display='none';
stringer.value="Show";
}

else if(document.getElementById(something).style.display == 'block'){
document.getElementById(something).style.display='none';
stringer.value="Show";
}

else if(document.getElementById(something).style.display == 'none'){
document.getElementById(something).style.display='block';
stringer.value="Hide";
}
}


