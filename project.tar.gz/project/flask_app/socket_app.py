from flask import Flask,render_template,request,redirect,url_for
from flask.ext.socketio import SocketIO, emit
import redis
import hashlib


app=Flask(__name__)
r=redis.Redis()
socketio = SocketIO(app)

@app.route('/', methods=['POST','GET','OPTIONS'])
def login():
	print("FOUND IN HERE")	
	if request.method=="GET":
		print("MAIN PAGE")
		return render_template('main.html')
	data="\n".join(r.lrange('chatroom',0,-1))	
	if request.form.has_key('user'):
		user=request.form['user']
		uid=r.hget('users',user)
		if not uid:
			error="Incorrect Username"
			return render_template('main_html',error=error)
		password=r.hget('user:%s'%(uid),'password')
		if request.form['password']==password:
			print("Successful Login")
			return render_template('user.html',user=user,data=data)
		else:
			error="Invalid Password"
			return render_template('main.html',error=error)
	else:
		user=request.form['register_user']
		password=hashlib.md5(request.form['register_pass']).hexdigest()
		if r.hexists('users',user):
			error="User %s already exists"%(user)
			return render_template('main.html',error=error)
		else:
			uid=r.incr('next_uid')
			r.hmset('user:%s'%(uid),{'username':user,'password':password})
			r.hset('users',user,uid)
			print("User %s with uid %s successfully created"%(user,uid))
			return render_template('user.html',user=user,data=data)

#@socketio.on('my event',namespace='/test')
#def test_message(message):
#	print('my_event message',message['data'])
#	r.rpush('chatroom',message['data'])
#	emit('my response',{'data':"<br>".join(r.lrange('chatroom',0,-1))})

@socketio.on('my broadcast event', namespace='/test')
def test_message(message):
	print('broadcast message',message['data'])
	r.rpush('chatroom','<label>'+message['user']+"</label>:\t"+message['data'])
	#length=int(r.llen('chatroom'))
	#r.ltrim('chatroom',length-10,length)
	emit('my response',{'data':"<br>".join(r.lrange('chatroom',0,-1))}, broadcast=True)

@socketio.on('connect', namespace='/test')
def test_connect():
	print('connect')
	emit('my response',{'data':"<label class='well'> Welcome you are now connected</label><br>"+"<br>".join(r.lrange('chatroom',0,-1))})

@socketio.on('disconnect', namespace='/test')
def test_disconnect():
	print('disconnect')
	emit('my response',{'data':'disconnected'})




if __name__== '__main__':
	socketio.run(app,host='0.0.0.0',debug=True)

