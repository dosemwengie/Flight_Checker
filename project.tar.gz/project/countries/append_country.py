import sys

files=sys.argv[1]
f=open(files,'r')
output=open('output/%s'%(files),'w')
for lines in f:
	lines=lines.split('\n')	
	output.write('%s,"%s"\n'%(''.join(lines),files))
