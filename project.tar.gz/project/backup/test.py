import json,operator
from datetime import datetime
def do_work(url_file,target_price,price_max,output):
	f=open(url_file,"r")
	price_point=float(price_max)*100
	target_point=float(target_price)*100
	json_data=f.read()
	python_obj=json.loads(json_data)
	FROM=python_obj['info']['from'][1]
	TO=python_obj['info']['to'][1]
	trial=open(output,"w")
	email_alert=open("alert_file",'a')
	if python_obj["return"]:
		price=max(int(python_obj["depart"][0][0][0]),int(python_obj["return"][0][0][0]))
		if price>price_point:
			print("No flights found, cheapest flight=%.2f...exiting"%(float(price)/100))
			trial.write("<h1 align='center'>%s <--> %s"%(python_obj['info']['from'][0],python_obj['info']['to'][0]))
			trial.write("<h3>No flights found, cheapest flight=%.2f"%(float(price)/100))
			trial.close()
			return 
		final_results={'MIN_TO':[],'MIN_FROM':[]}
	
		for hashes in python_obj["depart"]:
			if len(hashes[0]) < 2:
				continue
			if int(hashes[0][1])<=price:
				
				final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][1]])

		for hashes in python_obj["return"]:
			if int(hashes[0][0])<=price:
				final_results['MIN_TO'].append([python_obj["flights"][hashes[3]],hashes[0][0]])

		depart_dict=[]
		return_dict=[]

		for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
			depart_dict.append([int(keys[1]),keys[0][0]])

        	for keys in sorted(final_results['MIN_TO'],key=operator.itemgetter(1)):
			return_dict.append([int(keys[1]),keys[0][0]])

		trial.write("<html><br><br><body>")
		trial.write("<h1 align='center'>%s <--> %s"%(python_obj['info']['from'][0],python_obj['info']['to'][0]))
		inner,num=0,0
		for departs in depart_dict:
			for returns in return_dict:
				if departs[0]+returns[0]<=price_point:
					num+=1
					print("TOTAL:$%.2f"%(float(departs[0]+returns[0])/100))
					trial.write("<h1>TOTAL:$%.2f</h1>"%(float(departs[0]+returns[0])/100))
					trial.write("<h2>Option %d</h2>"%(num))
					#print("%.2f DEPART:%s RETURN:%s"%(float(departs[0]+returns[0])/100,departs[1],returns[1]))
					trial.write("\t\t\t<h3>DEPARTING</h3>")
					print("\t\t\tDEPARTING")
					for values in departs[1]:
						date1=values[2].find(':',-9)
						date1=values[2][:date1]
						date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


						date2=values[4].find(':',-9)
                                        	date2=values[4][:date2]
                                        	date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()

				
		
						print("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
						trial.write("%s(%s) %s %s ---> %s %s<br>"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
					trial.write("\t\t\t<br><h3>RETURNING</h3>")
					print("\t\t\tRETURNING")
					for values in returns[1]:
						date1=values[2].find(':',-9)
                                        	date1=values[2][:date1]
                                     	  	date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


                                        	date2=values[4].find(':',-9)
                                        	date2=values[4][:date2]
                                        	date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()

                                        	print("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
						trial.write("%s(%s) %s %s ---> %s %s<br>"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
					
					print("\n")
					trial.write("<br>")
				if departs[0]+returns[0]<=target_point:
                                        inner+=1
					email_alert.write("Price:$%.2f %s <---> %s:Option %d"%(float(departs[0]+returns[0])/100,python_obj['info']['from'][0],python_obj['info']['to'][0],inner))
                                        email_alert.write("\t\t\tDEPARTING")
                                        for values in departs[1]:
                                                date1=values[2].find(':',-9)
                                                date1=values[2][:date1]
                                                date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


                                                date2=values[4].find(':',-9)
                                                date2=values[4][:date2]
                                                date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()



                                                email_alert.write("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
                                        email_alert.write("\t\t\tRETURNING")
                                        for values in returns[1]:
                                                date1=values[2].find(':',-9)
                                                date1=values[2][:date1]
                                                date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


                                                date2=values[4].find(':',-9)
                                                date2=values[4][:date2]
                                                date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()

                                                email_alert.write("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))

                                        email_alert.write("\n")




		trial.write("</body>\n</html>")
		trial.close()
	else:	
		price=int(python_obj["depart"][0][0][0])
		if price>price_point:
			print("No flights found,cheapest flight %.2f...exiting"%(float(price)/100))
			trial.write("<h1 align='center'>%s --> %s"%(python_obj['info']['from'][0],python_obj['info']['to'][0]))
			trial.write("<h3>No flights found, cheapest flight=%.2f"%(float(price)/100))
			trial.close()
			return 
		final_results={'MIN_TO':[],'MIN_FROM':[]}
	
		for hashes in python_obj["depart"]:
			if len(hashes[0]) < 1:
				continue
			if int(hashes[0][0])<=price_point:
				
				final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][0]])


		depart_dict=[]

		for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
			depart_dict.append([int(keys[1]),keys[0][0]])

		#print(python_obj["depart"])
		#trial=open("trial.html","w")
		trial.write("<html><br><br><body>")
		trial.write("<h1 align='center'>%s --> %s"%(python_obj['info']['from'][0],python_obj['info']['to'][0]))
		inner,num=0,0
		for departs in depart_dict:
			if departs[0]<=price_point:
				num+=1
				print("TOTAL:$%.2f"%(float(departs[0])/100))
				trial.write("<h1>TOTAL:$%.2f</h1>"%(float(departs[0])/100))
				trial.write("<h2>Option %d</h2>"%(num))
				#print("%.2f DEPART:%s RETURN:%s"%(float(departs[0]+returns[0])/100,departs[1],returns[1]))
				trial.write("\t\t\t<h3>DEPARTING</h3>")
				print("\t\t\tDEPARTING")
				for values in departs[1]:
					date1=values[2].find(':',-9)
					date1=values[2][:date1]
					date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


					date2=values[4].find(':',-9)
                                        date2=values[4][:date2]
                                        date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()



					print("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
					trial.write("%s(%s) %s %s ---> %s %s<br>"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
					#print("\n")
					trial.write("<br>")
				print("\n")
			if departs[0]<=target_point:
                        	inner+=1
                                email_alert.write("%d. Price:$%.2f %s ---> %s"%(inner,float(departs[0])/100,python_obj['info']['from'][0],python_obj['info']['to'][0]))
                                email_alert.write("\t\t\tDEPARTING\n")
                                for values in departs[1]:
                                	date1=values[2].find(':',-9)
                                        date1=values[2][:date1]
                                        date1=datetime.strptime(date1,"%Y-%m-%dT%H:%M").ctime()


                                        date2=values[4].find(':',-9)
                                        date2=values[4][:date2]
                                        date2=datetime.strptime(date2,"%Y-%m-%dT%H:%M").ctime()


                                        email_alert.write("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],date1,values[3],date2))
                                        email_alert.write("\n")
				email_alert.write("\n")

		trial.write("</body>\n</html>")
		trial.close()
	email_alert.close()
#do_work()

