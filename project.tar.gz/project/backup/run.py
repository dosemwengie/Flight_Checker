import requests,subprocess
import psycopg2,os,sys
from test import do_work
def main():	
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
	cursor=conn.cursor()
	cursor.execute("select username,target_price,price_max,flying_from,flying_to,date_from,date_to,active,rowid from user_req")
	records=cursor.fetchall()
	for record in records:
		user=record[0].strip()
		target_price=str(record[1])
		price_max=str(record[2])
		flying_from=record[3].strip()
		flying_to=record[4].strip()
		date_from=str(record[5])
		date_to=str(record[6])
		active=str(record[7]).upper().strip()
		rowid=str(record[8]).strip()
		if date_to=="None":
			date_to=''
		user_url=''.join(["http://skiplagged.com/api/search.php?from=",flying_from,"&to=",flying_to,"&depart=",date_from,"&&return=",date_to,"&sort=cost"])
		print(user_url)
		res=requests.get(user_url)
		f=open('one_file','w')
		f.write('%s'%(res.text))
		f.close()
		output='_'.join([user,target_price,price_max,flying_from,flying_to,date_from,date_to])
		output=os.path.join('/user_data',user,output)
		email_alert=open("alert_file",'w')
		email_alert.close()
		do_work('one_file',target_price,price_max,output)
		if os.stat('alert_file')[6]>0:
			if active=='Y':
				cursor.execute("select email from users where username='%s'"%(user))
				record=cursor.fetchone()
				email=record[0].strip()
				cat=subprocess.Popen(("cat","alert_file"),stdout=subprocess.PIPE)
				outfile=subprocess.check_output(("mailx","-s",''.join([flying_from,'-->',flying_to]),email),stdin=cat.stdout)
				final_out='_'.join(['alert_file',target_price,user,flying_from,flying_to,date_from,date_to])
				os.rename('alert_file',os.path.join('/user_data',user,final_out))
				cursor.execute("Update user_req set active='N' where rowid='%s'"%(rowid))
				conn.commit()
			else:
				final_out='_'.join(['alert_file',target_price,user,flying_from,flying_to,date_from,date_to])
                                os.rename('alert_file',os.path.join('/user_data',user,final_out))
			
		cursor.execute("select filename from %s_data where filename='%s' "%(user,output))
		records=cursor.fetchall()
		if records:
			continue
		else:
			cursor.execute("insert into %s_data values('%s')"%(user,output))
			conn.commit()

main()
	
	 
