import json,sys,operator

def main():
	f=open(sys.argv[1],"r")
	price_point=float(sys.argv[2])*100
	
	json_data=f.read()
	python_obj=json.loads(json_data)
	FROM=python_obj['info']['from'][1]
	TO=python_obj['info']['to'][1]
	price=max(int(python_obj["depart"][0][0][0]),int(python_obj["return"][0][0][0]))
	if price>price_point:
		print("No flights found...exiting")
		return 
	#output=open("output.txt","a")
	#for files in python_obj.keys():
		#output.write("%s\n%s\n"%(files,python_obj[files]))
		#print(files)
	
	#test=[]
	#final_results={'MIN_TO':[[None],int(python_obj["depart"][0][0][0])],'MIN_FROM':[[None],int(python_obj["return"][0][0][0])]}
	final_results={'MIN_TO':[],'MIN_FROM':[]}
	
	for hashes in python_obj["flights"]:
		if python_obj["flights"][hashes][0][0][1]==FROM:
			if int(python_obj["flights"][hashes][1])<=price:
				#final_results['MIN_FROM'][1]=int(python_obj["flights"][hashes][1])
				print(python_obj["flights"][hashes][0:2])
				final_results['MIN_FROM'].append(python_obj["flights"][hashes][0:2])
				
		else:			
			if int(python_obj["flights"][hashes][1])<=price:
				#final_results['MIN_TO'][1]=int(python_obj["flights"][hashes][1])
				final_results['MIN_TO'].append(python_obj["flights"][hashes][0:2])


	#print(final_results)
	#print(sorted(test))
	#for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
		#print(float(price))/100
		#for values in keys[0]:
			#print("%s %s %s ---> %s %s"%(values[0],values[1],values[2],values[3],values[4]))
			#print(values)
		#print("\n")
	return
	for keys in sorted(final_results['MIN_TO'],key=operator.itemgetter(1)):
		#print(float(price))/100
		for values in keys[0]:
			print("%s %s %s ---> %s %s"%(values[0],values[1],values[2],values[3],values[4]))
			#print(values)
		print("\n")
	
main()

