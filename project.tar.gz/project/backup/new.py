import json,sys,operator
from collections import OrderedDict

def main():
	f=open(sys.argv[1],"r")
	price_point=float(sys.argv[2])*100
	
	json_data=f.read()
	python_obj=json.loads(json_data)
	FROM=python_obj['info']['from'][1]
	TO=python_obj['info']['to'][1]
	price=max(int(python_obj["depart"][0][0][0]),int(python_obj["return"][0][0][0]))
	if price>price_point:
		print("No flights found...exiting")
		return 
	final_results={'MIN_TO':[],'MIN_FROM':[]}
	
	for hashes in python_obj["depart"]:
		if len(hashes[0]) < 2:
			continue
		if int(hashes[0][1])<=price:
				
				final_results['MIN_FROM'].append([python_obj["flights"][hashes[3]],hashes[0][1]])

	for hashes in python_obj["return"]:
		if int(hashes[0][0])<=price:
				final_results['MIN_TO'].append([python_obj["flights"][hashes[3]],hashes[0][0]])

	depart_dict=[]
	return_dict=[]

	for keys in sorted(final_results['MIN_FROM'],key=operator.itemgetter(1)):
		depart_dict.append([int(keys[1]),keys[0][0]])

        for keys in sorted(final_results['MIN_TO'],key=operator.itemgetter(1)):
		return_dict.append([int(keys[1]),keys[0][0]])

	trial=open("trial.html","w")
	trial.write("<html>\n\n<body>")
	
	for departs in depart_dict:
		for returns in return_dict:
			if departs[0]+returns[0]<=price_point:
				print("TOTAL:%.2f"%(float(departs[0]+returns[0])/100))
				trial.write("TOTAL:%.2f\n"%(float(departs[0]+returns[0])/100))
				#print("%.2f DEPART:%s RETURN:%s"%(float(departs[0]+returns[0])/100,departs[1],returns[1]))
				trial.write("\t\t\tDEPARTING\n")
				print("\t\t\tDEPARTING")
				for values in departs[1]:
					print("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],values[2],values[3],values[4]))
					trial.write("%s(%s) %s %s ---> %s %s\n"%(values[0],python_obj["airlines"][values[0][:2]],values[1],values[2],values[3],values[4]))
				trial.write("\t\t\tRETURNING\n")
				print("\t\t\tRETURNING")
				for values in returns[1]:
                                        print("%s(%s) %s %s ---> %s %s"%(values[0],python_obj["airlines"][values[0][:2]],values[1],values[2],values[3],values[4]))
					trial.write("%s(%s) %s %s ---> %s %s\n"%(values[0],python_obj["airlines"][values[0][:2]],values[1],values[2],values[3],values[4]))
					
				print("\n")
				trial.write("\n")
	#print("\n\n\n\n")
	#print(return_dict)
	trial.write("</body>\n</html>")
	trial.close()
main()

