import requests
import psycopg2,os,sys
from test import do_work
def main():	
	user=sys.argv[1].lower().strip()
	conn=psycopg2.connect(host="mydb.cyfjdrvrxvsl.us-east-1.rds.amazonaws.com",user="root",password="nemeanllc",dbname="flight_tracker")
	cursor=conn.cursor()
	cursor.execute("select username,target_price,price_max,flying_from,flying_to,date_from,date_to from user_req where username='%s'"%(user))
	records=cursor.fetchall()
	for record in records:
		user=record[0].strip()
		target_price=str(record[1])
		price_max=str(record[2])
		flying_from=record[3].strip()
		flying_to=record[4].strip()
		date_from=str(record[5])
		date_to=str(record[6])
		if date_to=="None":
			date_to=''
		user_url=''.join(["http://skiplagged.com/api/search.php?from=",flying_from,"&to=",flying_to,"&depart=",date_from,"&&return=",date_to,"&sort=cost"])
		print(user_url)
		res=requests.get(user_url)
		f=open('one_file','w')
		f.write('%s'%(res.text))
		f.close()
		output='_'.join([user,target_price,price_max,flying_from,flying_to,date_from,date_to])
		output=os.path.join('/user_data',output)
		do_work('one_file',price_max,output)
		cursor.execute("select filename from %s_data where filename='%s' "%(user,output))
		records=cursor.fetchall()
		if records:
			continue
		else:
			cursor.execute("insert into %s_data values('%s')"%(user,output))
			conn.commit()

main()
	
	 
